// Update amount based on additional attendees
document.getElementById('additional_count').addEventListener('change', function() {
    var count = parseInt(this.value);
    var total = (count + 1) * 500;
    document.getElementById('total_amount').innerHTML = '₹' + total;
    document.getElementById('amount').value = total;
    
    // Add name fields for additional attendees
    var namesDiv = document.getElementById('additional_names');
    namesDiv.innerHTML = '';
    
    for(var i = 1; i <= count; i++) {
        var div = document.createElement('div');
        div.className = 'mb-3';
        div.innerHTML = '<label class="form-label">Attendee ' + i + ' Name</label>' +
                       '<input type="text" name="attendee_names[]" class="form-control" required>';
        namesDiv.appendChild(div);
    }
});

// Smooth scrolling for navigation links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        var target = document.querySelector(this.getAttribute('href'));
        if(target) {
            target.scrollIntoView({ behavior: 'smooth' });
        }
    });
});